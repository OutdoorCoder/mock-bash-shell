#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct hist
{
   char * command;
   int count;
};

typedef struct hist Hist;
