#include "../linkedlist/genericData.h"
#include "hist.h"

void * buildType(char * command, int size){
   
   if(command == NULL){
      printf("NULL command");
      exit(-1);
   }
   
   Hist * h = (Hist*)calloc(1, sizeof(Hist));
   h->command = (char*)calloc(100, sizeof(char));
   strcpy(h->command, command);
   h->count = size;
   
   return h;
}

 void printType(void * passedIn){
   Hist * h = (Hist*)passedIn;
   printf("%s\n", h->command);
 }
// //void * buildType_Prompt(FILE * fin);
int compare(const void * p1, const void * p2){
   if(p1 == NULL || p2 == NULL){
      printf("NULL inputs");
      exit(-1);
   }
   
   Hist * h1 = (Hist*)p1;
   Hist * h2 = (Hist*)p2;
   
   int x = strcmp(h1->command, h2->command);
   
   return x;
   
}


void cleanType(void * passedIn){
   
   if(passedIn == NULL){
      printf("NULL input");
      exit(-1);
   }
   
   Hist * h = (Hist*)passedIn;
   
   free(h->command);
   h->command = NULL;
   
   free(h);
   h = NULL;
}
