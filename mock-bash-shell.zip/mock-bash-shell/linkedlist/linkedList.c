#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "./linkedList.h"

LinkedList * linkedList(){
   LinkedList * list = (LinkedList*)malloc(sizeof(LinkedList));
   Node * temp = (Node*)malloc(sizeof(Node));
   temp->data = NULL;
   temp->next = NULL;
   temp->prev = NULL;
   
   list->head = temp;
   list->size = 0;
   
   return list;
}

void addLast(LinkedList * theList, Node * nn){

    if(nn == NULL){
      exit(-99);
    }
    if(theList == NULL){
      return;
   }
    
    if(theList->head->next == NULL) // or use if( ! theList.head )
    {
        theList->head->next = nn;
        nn->prev = theList->head;
        nn->next = NULL;
    }
    else
    {
        Node * temp = theList->head->next;
        
        while(temp->next != NULL){
            temp = temp->next;
        }
        
        temp->next = nn;
        nn->prev = temp;
        nn->next = NULL;
        
    }
    theList->size ++;
}

void addFirst(LinkedList * theList, Node * nn){

    if(nn == NULL){
      exit(-99);
    }
    if(theList == NULL){
      return;
   }
    
    if(theList->head->next == NULL) // or use if( ! theList.head )
    {
        theList->head->next = nn;
        nn->prev = theList->head;
        nn->next = NULL;
    }
    else
    {
        Node * temp = theList->head->next;
              
        nn->prev = theList->head;
        nn->next = temp;
        temp->prev = nn;
        theList->head->next = nn;
        
    }
    theList->size ++;
}

void removeItem(LinkedList * theList, Node * nn, void (*removeData)(void *), int (*compare)(const void *, const void *))
{
	if(nn == NULL)
	{
		perror("Node is NULL\n");
		exit(-99);
	}

	if(theList != NULL)
	{
		
		Node * cur = theList->head, *prev = NULL;
		while(cur != NULL && compare(nn->data, cur->data) != 0)
		{
			prev = cur;
			cur = cur->next;
		}
		
		if(prev == NULL)
		{
			theList->head = cur->next;
			removeData(cur->data);
			free(cur);
			cur = NULL;
			theList->size = theList->size - 1;
		}

		else if(cur == NULL)
		{
			printf("Not in the list\n");
		}

		else
		{
			prev->next = cur->next;
			removeData(cur->data);
			free(cur);
			cur = NULL;
			theList->size = theList->size - 1;
		}
	}// end if

	removeData(nn->data);
	free(nn);
	nn = NULL;

}// end removeItem


void clearList(LinkedList * theList, void (*removeData)(void *)){

   if(theList == NULL){
      return;
   }
   Node * temp;
   Node * curr = theList->head->next;
  
   while (curr != NULL)
    {
        temp = curr;
        curr = curr->next;
        removeData(temp->data);
        temp->data = NULL;
        free(temp);
        temp = NULL;
    }
    free(theList->head);
      
}

void printList(const LinkedList * theList, void (*convertData)(void *)){
   
   if(theList == NULL || theList->size == 0){
      printf("Empty List");
      return;
   }
   
   Node * curr = theList->head->next;

   while(curr != NULL){
      convertData(curr->data);
      curr = curr->next;
   }   
}
