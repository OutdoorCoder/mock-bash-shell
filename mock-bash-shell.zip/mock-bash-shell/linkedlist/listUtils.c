#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "./listUtils.h"

Node * buildNode(char * command, int size,  void *(*buildData)(char * command, int size) ){
   
   Node * nn = (Node*)malloc(sizeof(Node));
   
   nn->data = buildData(command, size);
   nn->next = NULL;
   nn->prev = NULL;
   
   return nn;
}

Node * buildNode_Type(void * passedIn){
   
   Node * nn = (Node*)malloc(sizeof(Node));
   
   nn->data = passedIn;
   nn->next = NULL;
   nn->prev = NULL;
   
   return nn;
}

void sort(LinkedList * theList, int (*compare)(const void *, const void *)){

   if(theList == NULL){
      exit(-99);
   }
   if(theList->size < 2){
      return;
   }
      
   Node *min, *start = theList->head->next, *cur;
   void *temp;
             
   for(; start->next != NULL; start = start->next)
   {
      min = start;
      for(cur = start->next; cur != NULL; cur = cur->next) {
         if(compare(cur->data, min->data ) < 0)
            min = cur;
      }
      //swap
      temp = start->data;
      start->data = min->data;
      min->data = temp;
   }
}

void buildList(LinkedList * myList, int total, char * command, void * (*buildData)(char * command, int size)){
   
   int ctr = total;

   while(ctr != 0 ){
      addFirst(myList, buildNode(command,myList->size, buildData));
      ctr--;
   }
}
