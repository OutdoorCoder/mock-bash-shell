#include <stdio.h>
#include <stdlib.h>
#include <string.h>


void forkIt(char ** argv, int argc){
   int status, res;
   pid_t pid;
   if(strcmp(argv[argc - 1], "&") == 0){
      
      pid = fork();
      
      if(pid != 0){
         waitpid(pid, &status, 0);
      }
      else{
         setpgid(0);
         res = execvp(argv[0], argv[1]);
         if(res){
            printf("Invalid command\n");
            exit(-1);
         }
      }
     }
     else{
        pid = fork();
         
         if(pid != 0){
            waitpid(pid, &status, 0);
         }
         else{
            
            res = execvp(argv[0], argv);
            if(res){
               printf("Invalid command\n");
               exit(-1);
            }
         }
     }
}
