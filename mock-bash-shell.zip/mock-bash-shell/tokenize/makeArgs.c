#include "makeArgs.h"

void clean(int argc, char **argv)
{
   int i;
	
   //printf("%s", *argv);
   //printf("%d", argc);
   for(i = 0; i < argc; i++){
	//      
	   free(((argv)[i]));
      argv[i] = NULL;
   }
   free(argv);
   argv = NULL;


}// end clean

void clean3d(char *** inputs,int pipeCount, int * countArray){
   
   int x, y;
   
   for(x = 0; x < pipeCount + 1; x++){
      for(y = 0; y < countArray[x]; y++){
         free(inputs[x][y]);
         inputs[x][y] = NULL;
      }
      free(inputs[x]);
      // free(countArray[x]);
      inputs[x] = NULL;
   }
   free(inputs);
   free(countArray);
   inputs = NULL;

}

void printargs(int argc, char **argv)
{
	int x;
	for(x = 0; x < argc; x++)
		printf("%s\n", argv[x]);

}// end printargs

int makeargs(char *s, char *** argv)
{

   //1. make a copy of s
   //2. count tokens in s
   //3. make the array size count + 1
   //4. walk through s -> tokenize again allocate memory for the token + 1
   //strcopy in argv
   

   char cpy[1000];
	strcpy(cpy, s);// = strdup(s);
   char * token;
   char * saveptr1;
   char * saveptr2;
   int count = 0, i;
   
  token = strtok_r(cpy, " ", &saveptr1);
	while(token != NULL)
	{
		count ++;
		token = strtok_r(NULL, " ", &saveptr1);
		//strip(token);
	}
	//printf("%d\n", count);


   
    (*argv) = (char**)calloc(count+1, sizeof(char*));
    token = strtok_r(s, " ",&saveptr2);
    //strip(token);
 
    (*argv)[0] = (char*)calloc(strlen(token) +1, sizeof(char));
    strcpy((*argv)[0], token);

   for(i = 1; i < count; i++)
   {
  // while(token != NULL){
      token = strtok_r(NULL, " ",&saveptr2);
    //  strip(token);
      (*argv)[i] = (char*)calloc(strlen(token) +1, sizeof(char));
      strcpy((*argv)[i], token);
	//i++; 
   }

    
   return count;

}// end makeArgs

