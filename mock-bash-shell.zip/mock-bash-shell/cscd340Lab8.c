

#include "./pipes/pipes.h"
#include "./utils/myUtils.h"
#include "./process/process.h"
#include "./tokenize/makeArgs.h"
#include "./linkedlist/linkedList.h"
#include "./linkedlist/listUtils.h"

int main()
{
  int argc, pipeCount, histCount, histFileCount, haveHistory;
  char **argv = NULL, s[MAX];
  char *** inputs = NULL;
  char * path = NULL;
  char oldPath[1000];
  int * countArray = NULL;
  int * fd = NULL;
  char * temp = NULL;
  char * temp2 = NULL;
  int boolean = 0;
  LinkedList * myList = linkedList();
  
  ///usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/usr/local/java/jdk1.7.0_45/bin:/usr/local/java/jdk1.7.0_45/jre/bin
//implement history file read and write
//in read history from file get the num of the largest history count
//and set one larger than that as the next history count
  
  strcpy(oldPath, getenv("PATH"));
  
  getBash(&path, &histCount, &histFileCount);
  //printf("%d %d", histCount, histFileCount);
  //printf("%s", path);
  setenv("PATH", path, 1);
  //printf("%s\n",getenv("PATH"));
  
  haveHistory = readHistoryFromFile(&myList, histCount);
  
 // path = NULL;
  
  
  do
  { 
   
   	printf("command?: ");
   	fgets(s, MAX, stdin);
         	strip(s);
            
      
     // printList(myList, printType);      
      if(s != NULL && strcmp(s, "") != 0 && strcmp(s, "!!") == 0){
         temp = getLastCommand(myList);
         strcpy(s ,temp);
        
      }
      else if(s != NULL && strcmp(s, "") != 0 && strncmp(s, "!", 1) == 0){
         temp2 = searchForCommand(s, myList);
         strcpy(s ,temp2);
     
      }
      else if(s != NULL && strcmp(s, "") != 0){
         if(myList->size < histCount){
            addLast(myList, buildNode(s, myList->size + 1, buildType));
         }
      }            
      if(s != NULL && strcmp(s, "") != 0 && checkStringForPath(s) == 0){
         setPath(s, &path);
         setenv("PATH", path, 1);
         printf("%s\n",getenv("PATH"));
      }
      else if(s != NULL && strcmp(s, "") != 0 && strcmp(s, "oldPath") == 0){
         setenv("PATH", oldPath, 1);
         printf("%s\n",getenv("PATH"));
      }
      else if(s != NULL && strcmp(s, "") != 0 && strcmp(s, "history") == 0){
         printHistory(myList, histCount);
      }
	else if(s != NULL && strcmp(s, "") != 0 && strncmp(s, "cd", 2) == 0){
         cd(s);
      }       
      else if(strcmp(s, "") != 0){      
      
         pipeCount = containsPipe(s);
         // printf("%d\n", pipeCount); 
         if(strcmp(s, "exit") != 0){
            if(pipeCount > 0){
               //get args, then pipeIt
               inputs = getInputs(s, pipeCount, &countArray);
               
               pipeIt(inputs, pipeCount, countArray, boolean, fd);
               clean3d(inputs, pipeCount,countArray);
            }//end if
            else
         	{
         		argc = makeargs(s, &argv);
         	  	if(argc != -1)
         	  		forkIt(argv, argc);
         	  
         	  	clean(argc, argv);
         	  	argv = NULL;
         	}//end else
          }//endif
      }//end else
   if(temp != NULL){
      free(temp);
      temp = NULL;
  }
  if(temp2 != NULL){
      free(temp2);
      temp2 = NULL;
  }
  }while(strcmp(s, "exit") != 0);
  
  writeToHistoryFile(myList, histFileCount);
  clearList(myList, cleanType);
   free(myList);
   myList = NULL;

  return 0;

}/* end main * cscd340Lab8.c
 *
 *  Created on: Apr 16, 2016
 *      Author: Cameron
 */



