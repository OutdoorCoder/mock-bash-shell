#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <unistd.h>
#include "myUtils.h"
#include "../hist/hist.h"
#include "../linkedlist/linkedList.h"
#include "../linkedlist/listUtils.h"


void strip(char *array)
{
	if(array == NULL)
	{
		perror("array is null");
		exit(-99);
	}// end if

	int len = strlen(array), x = 0;
   
	while(array[x] != '\0' && x < len)
	{
	  if(array[x] == '\r')
		 array[x] = '\0';

	  else if(array[x] == '\n')
		 array[x] = '\0';

	  x++;

}// end while
   
}// end strip

int menu()
{
   char temp[MAX];
   int choice;
   printf("1) Print the list\n");
   printf("2) Add First\n");
   printf("3) Add Last\n");
   printf("4) Sort\n");
   printf("5) Remove Item\n"); 
   printf("6) Quit\n"); 
   printf("Choice --> ");
   fgets(temp, MAX, stdin);
   choice = atoi(temp);

   
   while(choice < 1 || choice > 6)
   {
      printf("1) Print the list\n");
      printf("2) Add First\n");
      printf("3) Add Last\n");
      printf("4) Sort\n");
      printf("5) Remove Item\n"); 
      printf("6) Quit\n"); 
      printf("Choice --> ");
      fgets(temp, MAX, stdin);
      choice = atoi(temp);
   
   }// end while

   return choice;
   
}// end menu

void getBash(char ** path, int * histCount, int * histFileCount){

   FILE * fin = NULL;
   
   
   fin = fopen("./.myshrc", "r");
   if(fin == NULL){
	printf("No bash found\n");
      *histCount = 1000;
      *histFileCount = 2000;
      *path = getenv("PATH");
      return;
   }
   char lineOne[1000], lineTwo[1000], lineThree[1000];
   char * temp;
   
   fgets(lineOne, 1000, fin);
   temp = strtok(lineOne, "=");
   temp = strtok(NULL, "\0");
   *histCount = strtol(temp, NULL, 10);
   
   
   fgets(lineTwo, 1000, fin);
   temp = strtok(lineTwo, "=");
   temp = strtok(NULL, "\0");
   *histFileCount = strtol(temp, NULL, 10);
   
   
   
   fgets(lineThree, 1000, fin);
   fgets(lineThree, 1000, fin);
   temp = strtok(lineThree, ":");
   *path = strtok(NULL, "\0");
   strip(*path);
   
   fclose(fin);
   
}

int checkStringForPath(char * s){
   
   int res;
    
   char cpy[100]; 
   strcpy(cpy, s);
   
   if(cpy != NULL){
      res = strncmp(cpy, "PATH", 4);
      
      if(res == 0)
         return res;
   }
   
   
   return -1;
}


void setPath(char * s, char ** path){
   char * temp; 
   char cpy[1000];
   char cpy2[1000];
   strcpy(cpy2, *path); 
   strcpy(cpy, s);

   if(strncmp(s, "PATH=$PATH", 10) == 0){
      
      temp = strtok(cpy, "=");
      temp = strtok(NULL, "H");
      temp = strtok(NULL, "\0");
      strcat(cpy2, temp);
      strcpy(*path, cpy2);
      //*path = cpy;
      
   }
   else{
      temp = strtok(cpy, "=");
      temp = strtok(NULL, "\0");
      strcpy(*path, temp);
      //*path = cpy;
   }
   
}

char * getLastCommand(LinkedList * myList){
   if(myList->size == 0){
      printf("No commands in history\n");
      return;
   }
   Node * curr = myList->head->next;
   Hist * h;
   
   while(curr->next != NULL){
      curr = curr->next;
   }
   
   h = (Hist*)curr->data;
   char * temp = (char*)calloc(strlen(h->command) + 1, sizeof(char)); 
   strcpy(temp, h->command);
   
   return temp;
}

char * searchForCommand(char * s, LinkedList * myList){

   char cpy[100];
   strcpy(cpy, s);
   char * temp = (char*)calloc(strlen(cpy) + 1, sizeof(char));
   char * result = NULL;
   int len = 0;
   
   strcpy(temp, cpy);
   memmove(temp, temp+1, strlen(temp));

   char* end;
   int count;
   int res = strtol(temp, &end, 10);

   Node * cur = myList->head->next;
   Hist * h = NULL;
   if(!*end){
      while(cur != NULL){
      
         h = (Hist*)cur->data;
         count = (h->count);
         
         if(res - count == 0){
             
            result = (char*)calloc(strlen(h->command) + 1, sizeof(char));
            strcpy(result, h->command);
            free(temp);
            return result;
            
         }
         cur = cur->next;
         
      }
   }
   else{
      while(cur != NULL){
   
      h = (Hist*)cur->data;
      len = strlen(h->command);
      
         if(strlen(temp) <= len){
            
            if(strncmp(temp, h->command, strlen(temp)) == 0){
               
               result = (char*)calloc(len + 1, sizeof(char));
               strcpy(result, h->command);
               free(temp);
               return result;
            }
         }
      cur = cur->next;
      
      }
      

   }
  free(temp);
}

void printHistory(LinkedList * myList, int histCount){
   if(myList == NULL){
      printf("List is NULL");
      return;
   }
   if(histCount == 0){
      printf("histCount is zero, no history for you");
      return;
   }
   if(myList->size == 0){
      printf("List is empty, no history. Make some.");
      return;
   }
   
   Node * curr = myList->head->next;
   int ctr = 0;
   Hist * h;
   while(curr != NULL && ctr <= histCount){
      h = (Hist*)curr->data;
      printf("%d  %s\n", h->count, h->command);
      curr = curr->next;
      ctr++;
   }  
}

int readHistoryFromFile(LinkedList ** myList, int histCount){
   
   FILE * fin = NULL;
   int histNum = 0, ctr = 0;
   
   fin = fopen("./.mysh_history", "r");
   if(fin == NULL){
      printf("No history found\n");
      return 0;
   }
   char line[1000];
   char * temp;
   char * temp2;

   while (fgets(line, 1000, fin) != NULL && ctr < histCount) {
      
      temp = strtok(line, " \t");
      temp2 = strtok(NULL, "\0");
strip(temp2);
      histNum = strtol(temp, NULL, 10);
      addLast(*myList, buildNode(temp2, histNum, buildType));
      ctr++;
   }
   fclose(fin);
   return histNum;
   
//    fgets(lineOne, 1000, fin);
//    temp = strtok(lineOne, "   ");
//    temp2 = strtok(NULL, "\0");
//    
//    histNum = strtol(temp, NULL, 10);
//    addLast(myList, buildNode(temp2, histNum, buildType));
//    
//    while
//    
//    
//    fgets(lineTwo, 1000, fin);
//    temp = strtok(lineTwo, "=");
//    temp = strtok(NULL, "\0");
//    *histFileCount = strtol(temp, NULL, 10);

}
void writeToHistoryFile(LinkedList * myList, int histFileCount){
   
   if(myList->size == 0){
      printf("No history to write to file");
      return;
   }
   
   FILE * fin;
   fin = fopen("./.mysh_history", "w");
   
   Node * curr = myList->head->next;
   Hist * h;
   int ctr =0;
   
   while(curr != NULL && ctr < histFileCount){
      h = (Hist*)curr->data;
      fprintf(fin, "%d %s\n", h->count, h->command);
      ctr++;
      curr = curr->next;
   }
   
   fclose(fin);
   
   
}

void cd(char * s){
   
   char cpy[100];
   strcpy(cpy, s);
   char * temp;
   
   temp = strtok(cpy, " \t");
   temp = strtok(NULL, "\0");
   
   chdir(temp);
   
}
