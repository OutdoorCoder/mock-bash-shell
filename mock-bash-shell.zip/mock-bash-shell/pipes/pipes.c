#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include "./pipes.h"
#include "../tokenize/makeArgs.h"


int containsPipe(char *s){

   int i, count;
   for (i=0, count=0; s[i]; i++)
      count += (s[i] == '|');
      
   return count;
}

// char ** parsePrePipe(char *s, int * preCount){
// 
// 	*preCount = 0;	
// //	printf("%s", s);
// 	char * trash = strdup(s);
// 	char * array = strtok(trash, "|");
// 	
// 	
// 	char ** stuff = NULL;
// 	int res;
// 	res = makeargs(array, &stuff);
// 	*preCount = res;
// 	int i;
// //printf("first\n");
// //	for(i = 0; stuff[i]; i++){
// //		printf("%s", stuff[i]);
// //	}
// //free(trash);
// //fflush(stdout);
// 		
// 	//printf("here");
// 	free(trash);
// 	free(array);
// 	return stuff;
// }

// char ** parsePostPipe(char *s, int * postCount){
// 	
// 	char ** stuff = NULL;
// 
// 	*postCount = 0;
// 	//printf("second\n");
// 	//printf("%s\n", s);
// 	char * array = strtok(s, "|");
// 	array = strtok(NULL, "\0");
// 	//printf("%s\n", array);
// 	
// 	
// 	int res;
// 	res = makeargs(array, &stuff);
// 	*postCount = res;
// 	
// 	return stuff;
// }

char *** getInputs(char *s, int pipeCount, int ** countArray){
   char *** inputs = (char***)calloc((pipeCount + 1) + 1, sizeof(char**));
   *countArray = (int*)calloc(pipeCount + 1, sizeof(int));
   int i;
   
   char cpy[1000];
	strcpy(cpy, s);
	char * array = strtok(cpy, "|");
   
   inputs[0] = NULL;
	int res;
	res = makeargs(array, &(inputs[0]));
   (*countArray)[0] = res;
   // printf("%d\n", (*countArray)[0]);
   
   for(i = 0; i < pipeCount - 1; i++){
      
        array = strtok(NULL, "|");
        res = makeargs(array, &(inputs[i + 1]));
        (*countArray)[i + 1] = res; 
        // printf("%d\n", (*countArray)[i + 1]);
   }
   
   array = strtok(NULL, "\0");
   res = makeargs(array, &(inputs[pipeCount]));
   (*countArray)[pipeCount] = res;
  //  printf("%d\n", (*countArray)[pipeCount]);

   return inputs;   
}
   
/*
The pipeIt function needs to work with multiple pipes.
So their needs to be a conditional when pipeCount is greater than 1.
Therefore pipeCount needs to be a parameter.
When pipe count is greater than 1 do a recursive call

Need a 2d array of chars for pipe inputs as parameter

*/

void pipeIt(char *** commands, int pipeCount, int * countArray, int boolean, int * a){
	pid_t pid, pid1;
   int status1;

        fflush(stdout);
   if(boolean == 0){
	   boolean = 1;
      pid1 = fork();
      
   }
   else{
      pid_t pid;
      int fd[2], res, status;
   
   	res = pipe(fd);
   	pid = fork();
   
   	if(pid != 0)
   	{

	
         waitpid(pid, &status, 0);// waiting for child of this
   	   close(fd[1]);//close the write end of the pipe
   	   close(0);//close standard input
         dup(fd[0]);//dup the read end of the pipe into standard inputs place
         close(1);
         dup(*(a + 1));
         close(fd[0]);//close the read end of the pipe
         int err = execvp(commands[(pipeCount)][0], commands[(pipeCount)]);//run command
         
   	   if(err){//if theres and error exit back up
            printf("Invalid command\n");
            exit(-1);
         }
   
   		
   	}// end if AKA child
   	else
   	{
           // printf("\nhere\n");
         if(pipeCount > 1){
            //need to call pipeIt with the command[0], and command[1]
            int i;
	        // printf("here\n");
           char *** cpy = cpyCommands(commands, pipeCount, countArray);
           pipeIt(cpy, (pipeCount - 1), countArray, boolean, fd);
           
         }
   		

	
   		close(fd[0]);//close the read end of the pipe, don't need it
   		close(1);//close standard output
   		dup(fd[1]);//dup the write end of the pipe into standard outputs place
   		close(fd[1]);//close the write end of the pipe, don't need it now
   		int err = execvp(commands[(pipeCount - 1)][0], commands[(pipeCount - 1)]);//run command
   		if(err){//check for error
            printf("Invalid command\n");
            exit(-1);//exit back up
         }
   	}// end else AKA grandChild
      return;

   }   	
   
	if(pid1 == 0){
   	int fd[2], res, status;
   
   	res = pipe(fd);
   	pid = fork();
   
   	if(pid != 0)
   	{

	
         waitpid(pid, &status, 0);// waiting for child of this
   	   close(fd[1]);//close the write end of the pipe
   	   close(0);//close standard input
         dup(fd[0]);//dup the read end of the pipe into standard inputs place
         close(fd[0]);//close the read end of the pipe
         int err = execvp(commands[(pipeCount)][0], commands[(pipeCount)]);//run command
         
   	   if(err){//if theres and error exit back up
            printf("Invalid command\n");
            exit(-1);
         }
   
   		
   	}// end if AKA child
   	else
   	{
           // printf("\nhere\n");
         if(pipeCount > 1){
            //need to call pipeIt with the command[0], and command[1]
            int i;
	        // printf("here\n");
           char *** cpy = cpyCommands(commands, pipeCount, countArray);
           pipeIt(cpy, (pipeCount - 1), countArray,boolean, fd);
           
         }
   		

	      else{
   		close(fd[0]);//close the read end of the pipe, don't need it
   		close(1);//close standard output
   		dup(fd[1]);//dup the write end of the pipe into standard outputs place
   		close(fd[1]);//close the write end of the pipe, don't need it now
   		int err = execvp(commands[(pipeCount - 1)][0], commands[(pipeCount - 1)]);//run command
   		printf("here");
         if(err){//check for error
            printf("Invalid command\n");
            exit(-1);//exit back up
         }
         }
   	}// end else AKA grandChild
	}//end parent if
   else{
      waitpid(pid1, &status1, 0);
   }

}

/*
this function copys the substring of commands[1,(end of commands)] into a new char ***
*/

char *** cpyCommands(char *** commands, int pipeCount, int * countArray){
   char *** cpy = (char***)calloc(pipeCount + 1, sizeof(char**));
   int i,y;
   //there is pipeCount + 1 commands in the whole thing total
   //in cpy there are pipeCount arguments
   for(i = 0; i < pipeCount; i ++){
      //make a new 2d array of strings
      fflush(stdout);
      cpy[i] = (char**)calloc(countArray[i] + 1, sizeof(char*));
      for(y = 0; y < countArray[i]; y ++){
         /*
         for each string in the commands 2d string array
         copy that string into the new copy of the 2d string array
         */
         cpy[i][y] = (char*)calloc(strlen(commands[i][y]) + 1, sizeof(char));
         strncpy(cpy[i][y], commands[i][y], strlen(commands[i][y]));
	
      }   // end inner for
   }//end outer for
   fflush(stdout);

   return cpy;
   
}//end cpyCommand

