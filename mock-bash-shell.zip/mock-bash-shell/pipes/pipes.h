#ifndef PIPES_H
#define PIPES_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>

int containsPipe(char *s);
char ** parsePrePipe(char *s, int * preCount);
char ** parsePostPipe(char *s, int * postCount);
void pipeIt(char *** commands, int pipeCount, int * countArray, int boolean, int * fd);
char *** cpyCommands(char *** commands, int pipeCount, int * countArray);
char *** getInputs(char *s, int pipeCount, int ** countArray);
//void helperFork(char *** commands, int pipeCount, int * countArray, int * a);


#endif 

